# alumath_matrix  
A Python library for matrix multiplication.  

## **Installation**  
```bash
pip install alumath_matrix